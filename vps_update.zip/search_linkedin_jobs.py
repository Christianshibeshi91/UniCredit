import sys
import os
import json
import argparse
import random
import time
import urllib.parse
from pathlib import Path

LINKEDIN_EMAIL = os.getenv("LINKEDIN_EMAIL")
LINKEDIN_PASSWORD = os.getenv("LINKEDIN_PASSWORD")
LINKEDIN_LI_AT = os.getenv("LINKEDIN_LI_AT")
AUTH_FILE = Path("linkedin_auth.json")

SEARCH_QUERIES = [
    "Power Platform Developer",
    "Power Apps Developer",
    "Power Platform Architect",
    "Power Apps Architect",
    "Power Platform Administrator",
    "Power Apps Administrator",
    "Microsoft 365 Developer Power Platform",
    "Dynamics 365 CE Developer",
    "D365 Customer Engagement Developer"
]

COMPANY_BLACKLIST = [c.lower() for c in ["tsc", "ima", "quisitive", "planet technologies", "dice", "monster"]]
TITLE_BLACKLIST = [t.lower() for t in [
    "Dynamics F&O", 
    "Dynamics Functional and Operation", 
    "Dynamics Finanace and Operation",
    "Finance and Operations",
    "D365 F&O",
    "NetSuite",
    "Salesforce",
    "Workday"
]]

def random_delay(min_s=2.0, max_s=5.0):
    time.sleep(random.uniform(min_s, max_s))

def scrape_jobs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=".tmp/raw_jobs.json")
    parser.add_argument("--max-per-query", type=int, default=15)
    parser.add_argument("--limit-queries", type=int, default=0)
    parser.add_argument("--date-posted", default="") # Ignored
    args = parser.parse_args()

    try:
        from playwright.sync_api import sync_playwright # type: ignore
    except ImportError:
        print("ERROR: playwright not installed.")
        sys.exit(1)

    all_jobs = []
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, slow_mo=50)
        context_args = {
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "viewport": {"width": 1920, "height": 1080},
            "locale": "en-US",
            "timezone_id": "America/New_York"
        }
        
        # Priority 2: Use saved auth file
        if AUTH_FILE.exists():
            context_args["storage_state"] = str(AUTH_FILE)
            
        context = browser.new_context(**context_args)
        
        # Priority 1: Use direct LI_AT cookie if provided
        if LINKEDIN_LI_AT:
            print("  Injecting LI_AT cookie directly from .env...")
            context.add_cookies([{
                "name": "li_at",
                "value": LINKEDIN_LI_AT,
                "domain": ".www.linkedin.com",
                "path": "/"
            }])
            
        page = context.new_page()

        try:
            print("  Verifying LinkedIn Auth Session...")
            page.goto("https://www.linkedin.com/feed", wait_until="domcontentloaded")
            random_delay(3, 6)
            
            # Additional check to wait for elements to prove feed loaded
            try:
                page.wait_for_selector(".scaffold-layout__main", timeout=5000)
            except:
                pass 
                
            if "login" in page.url or "checkpoint" in page.url or "auth" in page.url:
                print(f"  ERROR: Auth session expired. Current URL: {page.url}")
                page.screenshot(path=".tmp/auth_error_screenshot.png")
                print("  Saved screenshot of the error to .tmp/auth_error_screenshot.png for debugging.")
                sys.exit(1)
                
            print("  ✓ Authentication successful. Commencing scrape...")
            
            queries_to_run = SEARCH_QUERIES
            if args.limit_queries > 0:
                queries_to_run = random.sample(SEARCH_QUERIES, min(args.limit_queries, len(SEARCH_QUERIES)))
            
            for query in queries_to_run:
                print(f"\n  🔍 Searching: {query} (Remote, Past 24 hours)")
                encoded_q = urllib.parse.quote(query)
                # f_WT=2 means Remote, f_TPR=r86400 means Past 24 hours
                search_url = f"https://www.linkedin.com/jobs/search/?keywords={encoded_q}&location=United%20States&f_TPR=r86400&f_WT=2&sortBy=DD"
                
                page.goto(search_url, wait_until="domcontentloaded")
                random_delay(3, 5) 
                
                # Scroll a bit
                for _ in range(5):
                    page.evaluate("window.scrollBy(0, document.body.scrollHeight)")
                    random_delay(1, 2)
                    
                # The side pane of job cards
                job_cards_selector = "li.jobs-search-results__list-item, div.job-card-container"
                job_cards = page.query_selector_all(job_cards_selector)
                
                if not job_cards:
                    print(f"    No results found for {query}.")
                    continue
                    
                print(f"    Found {len(job_cards)} results on page 1. Extracting top {args.max_per_query}...")
                
                count = 0
                for card in job_cards:
                    if count >= args.max_per_query:
                        break
                        
                    try:
                        title_el = card.query_selector("a.job-card-list__title, a.job-card-container__link, strong")
                        company_el = card.query_selector(".job-card-container__company-name, .artdeco-entity-lockup__subtitle")
                        location_el = card.query_selector(".job-card-container__metadata-item, .artdeco-entity-lockup__caption")
                        
                        if not title_el:
                            continue
                            
                        title = title_el.inner_text().strip()
                        company = company_el.inner_text().strip() if company_el else "Unknown"
                        location = location_el.inner_text().strip() if location_el else "Unknown"
                        
                        # Blacklist check
                        title_low = str(title).lower()
                        company_low = str(company).lower()
                        
                        skip = False
                        for t in TITLE_BLACKLIST:
                            if str(t) in title_low: # type: ignore
                                skip = True
                                break
                        for c in COMPANY_BLACKLIST:
                            if str(c) in company_low: # type: ignore
                                skip = True
                                break
                        if skip:
                            print(f"    - Skipped (Blacklisted): {title} at {company}")
                            continue

                        # Reposted check
                        card_text = card.inner_text().lower()
                        if "reposted" in card_text:
                            print(f"    - Skipped (Reposted): {title} at {company}")
                            continue

                        # Remote check (LinkedIn sometimes sneaks in hybrid/onsite)
                        if "remote" not in str(location).lower() and "remote" not in str(title).lower() and "remote" not in card_text:
                            print(f"    - Skipped (Not Remote): {title} at {company}")
                            continue
                            
                        # Click the card to open details pane
                        card.scroll_into_view_if_needed()
                        card.click()
                        random_delay(2, 4)
                        
                        # Extract description
                        desc_el = page.query_selector(".jobs-description__content")
                        desc_text = desc_el.inner_text() if desc_el else ""
                        if not desc_text:
                            desc_el = page.query_selector("#job-details")
                            desc_text = desc_el.inner_text() if desc_el else "No Description"
                            
                        # Easy apply button check
                        button_text = ""
                        apply_btn = page.query_selector('.jobs-apply-button')
                        if apply_btn:
                            button_text = apply_btn.inner_text().strip().lower()
                        is_easy_apply = "easy apply" in button_text if apply_btn else False
                        
                        # Job URL and ID
                        href = title_el.get_attribute("href")
                        job_id = "unknown"
                        if href and "/view/" in href:
                            job_id = href.split("/view/")[1].split("/")[0].split("?")[0]
                        
                        job_url = f"https://www.linkedin.com/jobs/view/{job_id}" if job_id != "unknown" else href
                        
                        if job_url not in [j["job_url"] for j in all_jobs]:
                            job_data = {
                                "job_id": job_id,
                                "title": title,
                                "company": company,
                                "location": location,
                                "job_url": job_url,
                                "description": desc_text,
                                "salary": None,
                                "is_easy_apply": is_easy_apply,
                                "date_posted": "Past 24 hours",
                                "source": "linkedin"
                            }
                            all_jobs.append(job_data)
                            print(f"    + Added: {title} at {company} (Easy Apply: {is_easy_apply})")
                        
                        count += 1
                        
                    except Exception as e:
                        print(f"    Error parsing a job: {e}")
                        continue
                        
        except Exception as e:
            print(f"  ERROR: Exception during scraping: {e}")
            sys.exit(1)
        finally:
            browser.close()

    print(f"\nDONE: Total unique jobs found: {len(all_jobs)}")
    
    unique_jobs = {j["job_url"]: j for j in all_jobs}.values()
    
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(list(unique_jobs), f, indent=2)
        
    print(json.dumps({
        "status": "ok",
        "count": len(unique_jobs),
        "output": str(out_path)
    }))

if __name__ == "__main__":
    scrape_jobs()
